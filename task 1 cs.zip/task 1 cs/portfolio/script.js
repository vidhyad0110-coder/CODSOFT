const preloader = document.getElementById("preloader");
const header = document.getElementById("header");
const menuToggle = document.getElementById("menuToggle");
const navMenu = document.getElementById("navMenu");
const navLinks = document.querySelectorAll(".nav a");

window.addEventListener("load", () => {
    setTimeout(() => {
        preloader.classList.add("hidden");
    }, 700);
});

menuToggle.addEventListener("click", () => {
    navMenu.classList.toggle("open");
});

navLinks.forEach((link) => {
    link.addEventListener("click", () => {
        navMenu.classList.remove("open");
    });
});

window.addEventListener("scroll", () => {
    if (window.scrollY > 40) {
        header.classList.add("scrolled");
    } else {
        header.classList.remove("scrolled");
    }

    highlightActiveNav();
});

const revealItems = document.querySelectorAll(".reveal");

const revealObserver = new IntersectionObserver(
    (entries) => {
        entries.forEach((entry) => {
            if (entry.isIntersecting) {
                entry.target.classList.add("visible");
            }
        });
    },
    {
        threshold: 0.2,
    }
);

revealItems.forEach((item) => revealObserver.observe(item));

const words = ["AI Precision", "Futuristic UI", "Scalable Code", "Product Vision"];
const typedElement = document.getElementById("typedText");
let wordIndex = 0;
let letterIndex = 0;
let deleting = false;

function typingEffect() {
    const currentWord = words[wordIndex];

    if (!deleting) {
        typedElement.textContent = currentWord.slice(0, letterIndex + 1);
        letterIndex += 1;

        if (letterIndex === currentWord.length) {
            deleting = true;
            setTimeout(typingEffect, 1100);
            return;
        }
    } else {
        typedElement.textContent = currentWord.slice(0, letterIndex - 1);
        letterIndex -= 1;

        if (letterIndex === 0) {
            deleting = false;
            wordIndex = (wordIndex + 1) % words.length;
        }
    }

    setTimeout(typingEffect, deleting ? 45 : 90);
}

typingEffect();

function highlightActiveNav() {
    const sections = document.querySelectorAll("main section[id]");
    const offset = window.scrollY + 180;

    sections.forEach((section) => {
        const sectionTop = section.offsetTop;
        const sectionHeight = section.offsetHeight;
        const sectionId = section.getAttribute("id");

        if (offset >= sectionTop && offset < sectionTop + sectionHeight) {
            navLinks.forEach((link) => {
                link.classList.toggle("active", link.getAttribute("href") === "#" + sectionId);
            });
        }
    });
}

highlightActiveNav();
