# NexaFlow - Quick Reference Guide

## ⚡ Quick Start (3 Steps)

### Step 1: Download Live Server
- VS Code → Extensions (Ctrl+Shift+X)
- Search "Live Server"
- Install by Ritwick Dey

### Step 2: Open Project
- File → Open Folder
- Select `task 2 cs` folder
- Click Open

### Step 3: Run Website
- Right-click `index.html`
- Click "Open with Live Server"
- Website opens automatically!

---

## 🎯 What's Inside

### Files You Need:
- `index.html` - Main page (don't delete!)
- `style.css` - All styling (don't delete!)
- `script.js` - Interactive features (don't delete!)

### Optional Files:
- `README.md` - Full documentation
- `CUSTOMIZE.css` - Color presets (reference only)
- `images/` - For your custom images
- `assets/` - For icons/fonts

---

## 🎨 5 Easiest Customizations

### 1. Change Colors (30 seconds)
**Open `style.css` and find (line ~24):**
```css
--primary-gradient: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
--accent-color: #6366f1;
```

**Change to your colors:**
```css
--primary-gradient: linear-gradient(135deg, #3b82f6 0%, #1e40af 100%);
--accent-color: #3b82f6;
```

✅ DONE! All colors update instantly.

### 2. Change Company Name (10 seconds)
**Open `index.html` and find:**
```html
<span class="logo-text">NexaFlow</span>
```

**Change to:**
```html
<span class="logo-text">Your Company</span>
```

### 3. Change Main Headline (10 seconds)
**Open `index.html` and find:**
```html
<h1 class="hero-title">Experience the Future of Innovation</h1>
```

**Change to your headline:**
```html
<h1 class="hero-title">Your Amazing Headline Here</h1>
```

### 4. Change Button Text (10 seconds)
**Find and change all CTA buttons:**
```html
<button class="cta-button primary-btn">Get Started Now</button>
```

### 5. Add Your Own Images (1 minute)
**In `images/` folder, add your images**
**Replace SVG with your image:**
```html
<img src="images/your-image.png" alt="Description">
```

---

## 📱 Mobile Testing

**To test on mobile:**
1. Press F12 (open DevTools)
2. Click the Phone/Mobile icon
3. Choose device size
4. Refresh page

**Or test on real phone:**
1. Find your IP: Run `ipconfig` in terminal
2. On phone, visit: `http://YOUR_IP:5500`

---

## 🎬 Feature Checklist

- ✅ **Sticky Navigation** - Navbar stays on scroll
- ✅ **Mobile Menu** - Hamburger on mobile
- ✅ **Hero Section** - Big headline with animations
- ✅ **Feature Cards** - 6 feature cards with hover effects
- ✅ **About Section** - Company info with stats
- ✅ **Services** - 4 service cards
- ✅ **Testimonials** - 3 customer reviews
- ✅ **CTA Section** - Bold call-to-action
- ✅ **Footer** - Links and social icons
- ✅ **Animations** - Fade, float, hover effects
- ✅ **Responsive** - Mobile, tablet, desktop

---

## 🔧 Common Changes

### Add New Feature Card
**Copy this block in Features section:**
```html
<div class="feature-card">
    <div class="feature-icon">⭐</div>
    <h3>New Feature</h3>
    <p>Your description here</p>
</div>
```

Paste as many times as you want. Grid handles it!

### Change Contact Info
**Find in Footer:**
```html
<p>Email: hello@nexaflow.com</p>
<p>Phone: +1 (555) 123-4567</p>
```

Replace with your info.

### Remove a Section
**Find the `<section>` tag**
**Delete entire section block**

The page will auto-adjust!

---

## ⌨️ Keyboard Shortcuts

- **ESC** - Close mobile menu
- **Ctrl+S** - Save file
- **Ctrl+Shift+X** - Extensions (install Live Server)
- **F12** - Open DevTools

---

## 🐛 If Something Breaks

### Colors not changing?
- Hard refresh: **Ctrl+Shift+R** (Windows)
- Or **Cmd+Shift+R** (Mac)

### Mobile menu not working?
- Check `script.js` is linked at bottom of HTML
- Open DevTools (F12) and check Console for errors

### Styles look weird?
- Make sure `style.css` is in same folder
- Refresh page (F5)

### Images not showing?
- Put images in `images/` folder
- Use correct path: `images/filename.png`

---

## 📚 Learning Resources

**Color Generators:**
- https://coolors.co
- https://colordot.it
- https://colors.eva.design

**Gradient Maker:**
- https://cssgradient.io

**Image Compression:**
- https://tinypng.com
- https://squoosh.app

**Icon Libraries:**
- https://heroicons.com
- https://tabler-icons.io

---

## 🚀 Before Going Live

- [ ] Replace all placeholder text
- [ ] Update company name
- [ ] Change brand colors
- [ ] Add your images
- [ ] Update contact info
- [ ] Test on mobile (F12)
- [ ] Remove unused sections
- [ ] Check all links work

---

## 🎯 Color Codes to Use

**Popular Modern Colors:**
- Blue: `#3b82f6` or `#0ea5e9`
- Green: `#10b981` or `#059669`
- Purple: `#8b5cf6` or `#7c3aed`
- Pink: `#ec4899` or `#db2777`
- Orange: `#f97316` or `#ea580c`
- Red: `#ef4444` or `#dc2626`

**For Gradients (pick 2 colors):**
```css
linear-gradient(135deg, COLOR1 0%, COLOR2 100%)
```

---

## 💡 Pro Tips

1. **Use gradient for modern look:**
   ```css
   background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
   ```

2. **Rounded corners look premium:**
   ```css
   border-radius: 16px;  /* More rounded = more modern */
   ```

3. **Soft shadows = premium feel:**
   ```css
   box-shadow: 0 10px 40px rgba(0, 0, 0, 0.15);
   ```

4. **Hover effects grab attention:**
   ```css
   transform: translateY(-5px);  /* Lift on hover */
   transition: all 300ms ease-out;  /* Smooth animation */
   ```

---

## 📞 Troubleshooting Checklist

| Problem | Solution |
|---------|----------|
| Live Server won't start | Restart VS Code |
| Website looks wrong | Hard refresh (Ctrl+Shift+R) |
| Mobile menu broken | Check script.js is linked |
| Images not showing | Check `images/` folder path |
| Colors not changing | Clear browser cache |
| Page scrolling weird | Check body overflow settings |

---

## ✨ Next Steps

1. **Customize colors** to match your brand
2. **Update text** with your content
3. **Add images** to images folder
4. **Test on mobile** using DevTools
5. **Deploy** using Netlify/GitHub Pages

---

## 🌟 You're All Set!

Your landing page is ready to customize and launch. Start with the **5 easiest customizations** above, then explore more advanced options.

**Remember:** Every change you make will look professional because the design system handles it!

Happy building! 🚀
