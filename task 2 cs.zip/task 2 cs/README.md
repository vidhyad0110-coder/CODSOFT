# NexaFlow - Premium Modern Landing Page

## 📋 Project Overview

NexaFlow is a **production-ready, premium modern landing page** built with pure HTML5, CSS3, and Vanilla JavaScript. It features a stunning design with glassmorphism, smooth animations, responsive layout, and all the components needed for a professional SaaS or startup website.

**Key Highlights:**
- ✨ Modern glassmorphism design
- 🎨 Beautiful gradient backgrounds
- 📱 Fully responsive (Mobile-first)
- ⚡ Smooth animations and transitions
- 🔧 Zero dependencies (No frameworks)
- 🎯 Professional UI/UX
- 💨 Fast and optimized
- ♿ Accessible design

---

## 📁 Project Structure

```
task 2 cs/
├── index.html          # Main HTML file (all sections)
├── style.css          # Complete CSS styling & animations
├── script.js          # Interactive features & animations
├── README.md          # This file
├── assets/            # For icons, fonts, etc.
└── images/            # For custom images
```

---

## 🚀 Quick Start Guide

### Step 1: Open in VS Code
1. Open VS Code
2. Click "File" → "Open Folder"
3. Select the `task 2 cs` folder
4. All files will appear in the Explorer panel

### Step 2: Install Live Server Extension
1. Click the **Extensions** icon (Ctrl+Shift+X)
2. Search for "Live Server"
3. Install the extension by "Ritwick Dey"

### Step 3: Run the Project
1. Right-click on `index.html`
2. Select **"Open with Live Server"**
3. The website will open in your browser automatically

### Step 4: View on Mobile
1. The page is fully responsive
2. Press F12 to open Developer Tools
3. Click the "Mobile" icon to test responsive design

---

## 🎨 Customization Guide

### Change Brand Color

**Find this in `style.css` (Top of file):**
```css
:root {
    --primary-gradient: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
    --accent-color: #6366f1;
}
```

**Replace with your colors:**
- **Primary Gradient**: Main brand color (top-right)
- **Accent Color**: Hover effects and highlights

**Example - Blue to Purple:**
```css
--primary-gradient: linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%);
--accent-color: #3b82f6;
```

### Change Company Name

**In `index.html`, find the navbar:**
```html
<span class="logo-text">NexaFlow</span>
```

**Change to your company name:**
```html
<span class="logo-text">YourCompany</span>
```

**Also in footer:**
```html
<h3>YourCompany</h3>
```

### Edit Text Content

**Hero Section** - Find in `index.html`:
```html
<h1 class="hero-title">Experience the Future of Innovation</h1>
<p class="hero-subtitle">Your custom subtitle here...</p>
```

**Features Section:**
```html
<h3>Lightning Fast</h3>
<p>Your feature description here...</p>
```

Replace all text content as needed. The styling will remain beautiful!

### Change Images

**Add your own images:**

1. Place image files in the `images/` folder
2. Replace SVG placeholders in HTML:

**Before:**
```html
<svg class="hero-illustration" viewBox="0 0 400 400">...</svg>
```

**After:**
```html
<img src="images/your-image.png" alt="Description" class="hero-illustration">
```

### Customize Button Text

**Find buttons in `index.html`:**
```html
<button class="cta-button primary-btn">Get Started Now</button>
<button class="cta-button secondary-btn">Learn More</button>
```

Change the text inside the buttons as needed.

### Update Contact Information

**Footer Section:**
```html
<p>Email: hello@nexaflow.com</p>
<p>Phone: +1 (555) 123-4567</p>
<p>Address: San Francisco, CA</p>
```

Replace with your actual contact details.

---

## 🎭 Design Features Explained

### Glassmorphism Effect
Modern frosted glass effect used in:
- Navbar (`.navbar`)
- Cards (`.feature-card`, `.service-card`)
- Buttons with backdrop blur

**CSS Code:**
```css
background: rgba(255, 255, 255, 0.05);
backdrop-filter: blur(10px);
border: 1px solid rgba(255, 255, 255, 0.1);
```

### Gradient Text
Applied to headings for premium look:
```css
background: linear-gradient(135deg, #ffffff 0%, #e0e7ff 100%);
-webkit-background-clip: text;
-webkit-text-fill-color: transparent;
background-clip: text;
```

### Smooth Animations
- **Fade In Up**: Elements appear smoothly
- **Float**: Floating animations on images
- **Hover Lift**: Cards lift on hover
- **Gradient Shift**: Animated background

### Responsive Design
Uses CSS Grid and Flexbox:
- Mobile: 1 column
- Tablet: 2-3 columns
- Desktop: 3-4 columns

---

## 🔧 Advanced Customization

### Change Section Background

**Find section backgrounds in `style.css`:**

```css
.features {
    background: rgba(30, 41, 59, 0.5);
}
```

Change the `rgba` values:
- First 3 numbers: RGB color
- Last number: opacity (0-1)

### Modify Animation Speed

**Find in `style.css`:**
```css
:root {
    --transition-fast: 150ms ease-out;
    --transition-normal: 300ms ease-out;
    --transition-slow: 500ms ease-out;
}
```

Increase/decrease the millisecond values to speed up or slow down animations.

### Add New Sections

1. Copy an existing section (e.g., `<section class="features">`)
2. Paste it in `index.html`
3. Add styles to `style.css` for the new section
4. The responsive design will work automatically

---

## 📱 Mobile Optimization

The site is **fully responsive**:

- **Mobile** (< 480px): Single column layout
- **Tablet** (480px - 768px): 2 columns
- **Desktop** (> 768px): 3-4 columns

**Mobile Menu:**
- Hamburger menu appears on screens < 768px
- Smooth slide-down animation
- Auto-closes when link is clicked

---

## ⚡ Performance Tips

1. **Compress Images**: Use tinypng.com for image compression
2. **Minimize CSS/JS**: Already optimized, but can minify further
3. **Lazy Load Images**: Add `loading="lazy"` to img tags
4. **Caching**: Browser caches CSS/JS automatically

**Current Performance:**
- ✅ 0 external dependencies
- ✅ Fast load time
- ✅ Smooth 60 FPS animations
- ✅ Mobile-optimized

---

## 🎯 SEO Best Practices

The HTML includes:
- Semantic HTML5 elements (`<section>`, `<nav>`, `<footer>`)
- Meta tags for responsiveness
- Proper heading hierarchy (H1, H2, H3)
- Alt attributes ready for images

**To improve SEO:**
1. Add meta description in `<head>`
2. Add proper image alt text
3. Add structured data (Schema.org)
4. Create sitemap.xml

---

## 🔐 Security & Accessibility

- ✅ No external trackers
- ✅ No JavaScript vulnerabilities
- ✅ Keyboard navigation support
- ✅ Screen reader friendly
- ✅ WCAG 2.1 AA compliant

---

## 🎨 Color Palette

**Current Colors:**
```
Primary Blue: #6366f1
Primary Purple: #8b5cf6
Secondary Pink: #ec4899
Secondary Orange: #f59e0b
Dark Background: #0f172a
Text Primary: #ffffff
Text Secondary: rgba(255, 255, 255, 0.7)
```

**To use different colors:**
1. Edit CSS variables in `:root`
2. All components will automatically update

---

## 📋 Checklist for Launch

- [ ] Update company name and logo
- [ ] Replace placeholder text with real content
- [ ] Update contact information
- [ ] Add custom images
- [ ] Change brand colors if needed
- [ ] Test on mobile devices
- [ ] Update social media links
- [ ] Add real links to buttons
- [ ] Test all navigation links
- [ ] Verify form submissions (if adding backend)

---

## 🚀 Deploy Your Website

### Option 1: GitHub Pages (Free)
```bash
1. Push files to GitHub
2. Go to Settings → Pages
3. Select main branch
4. Your site is live in minutes
```

### Option 2: Netlify (Free)
```bash
1. Drag and drop folder to netlify.com
2. Instant deployment
3. Auto SSL certificate
```

### Option 3: Vercel (Free)
```bash
1. Connect GitHub repo
2. Auto-deploys on push
3. Instant HTTPS
```

---

## 🐛 Troubleshooting

### Live Server not working?
- Restart VS Code
- Reinstall Live Server extension
- Check port 5500 is not blocked

### Styles not showing?
- Hard refresh: Ctrl+Shift+R
- Clear browser cache
- Check style.css is in same folder

### Mobile menu not working?
- Check script.js is linked in HTML
- Check browser console for errors (F12)

### Images not showing?
- Verify image path in `images/` folder
- Check file extension (.png, .jpg, etc.)
- Use relative paths: `images/filename.png`

---

## 📚 Learning Resources

- **CSS Gradients**: https://cssgradient.io/
- **Animations**: https://animate.style/
- **Color Picker**: https://colorpicker.com/
- **Responsive Design**: https://responsively.app/

---

## 💡 Customization Ideas

1. **Add Blog Section**: Copy features section, add blog cards
2. **Add Newsletter**: Add form in footer
3. **Add Live Chat**: Integrate Intercom or similar
4. **Add Pricing Table**: Create pricing section
5. **Add Team Section**: Showcase team members
6. **Add Case Studies**: Add success stories

---

## 📞 Support & Help

If you encounter any issues:

1. Check the **Troubleshooting** section above
2. Clear browser cache and refresh
3. Restart VS Code
4. Check browser console (F12) for errors

---

## ✨ What's Included

### Sections
- ✅ Sticky Navigation Bar
- ✅ Hero Section with CTA
- ✅ Features Grid (6 items)
- ✅ About Section
- ✅ Services Section (4 items)
- ✅ Testimonials (3 items)
- ✅ Call-to-Action Banner
- ✅ Footer with Links

### Features
- ✅ Responsive Design
- ✅ Mobile Menu
- ✅ Smooth Animations
- ✅ Hover Effects
- ✅ Gradient Backgrounds
- ✅ Glassmorphism
- ✅ Floating Elements
- ✅ Counter Animations
- ✅ Active Nav Links
- ✅ Parallax Effects

### JavaScript Features
- ✅ Mobile Menu Toggle
- ✅ Smooth Scrolling
- ✅ Scroll Reveal Animations
- ✅ Ripple Button Effect
- ✅ Navbar Scroll Effect
- ✅ Counter Animations
- ✅ Parallax on Mouse Move
- ✅ Keyboard Navigation

---

## 🎓 Learning Value

This project demonstrates:
- Modern HTML5 structure
- Advanced CSS3 techniques
- Vanilla JavaScript ES6+
- Responsive design principles
- Web performance optimization
- UI/UX best practices
- Animation and transitions
- Mobile-first approach

---

## 📝 Notes

- All code is commented for learning
- No frameworks needed
- Production-ready code
- Beginner-friendly structure
- Easy to customize

---

## 🌟 Make It Your Own

This is a template. Customize everything:
- Colors, fonts, spacing
- Content and copy
- Images and graphics
- Animations and effects
- Section layout

**The design is just a starting point. Make it unique!**

---

**Happy building! 🚀✨**

*Last Updated: May 2026*
*Built with ❤️ for startup innovators*
