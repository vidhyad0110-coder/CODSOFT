const expressionEl = document.getElementById("expression");
const resultEl = document.getElementById("result");
const keys = document.querySelectorAll(".key");
const historyPanel = document.getElementById("historyPanel");
const historyList = document.getElementById("historyList");
const historyToggle = document.getElementById("historyToggle");

let expression = "";
let justEvaluated = false;
const history = [];
const MAX_LENGTH = 32;

const operators = ["+", "-", "*", "/"];

function updateDisplay() {
  expressionEl.textContent = expression || "0";

  if (!expression) {
    resultEl.textContent = "0";
    return;
  }

  try {
    if (endsWithOperator(expression) || expression === "." || expression === "-") {
      resultEl.textContent = "...";
      return;
    }

    const value = evaluateExpression(expression);
    resultEl.textContent = formatResult(value);
  } catch {
    resultEl.textContent = "Error";
  }
}

function appendValue(value) {
  if (expression.length >= MAX_LENGTH) {
    return;
  }

  if (justEvaluated && (isDigit(value) || value === ".")) {
    expression = "";
  }

  if (isDigit(value)) {
    if (justEvaluated) {
      justEvaluated = false;
    }

    expression += value;
    updateDisplay();
    return;
  }

  if (value === ".") {
    if (justEvaluated) {
      expression = "";
      justEvaluated = false;
    }

    if (!canAddDecimal(expression)) {
      return;
    }

    expression += needsLeadingZeroForDecimal(expression) ? "0." : ".";
    updateDisplay();
    return;
  }

  if (value === "%") {
    if (!expression || endsWithOperator(expression) || expression.endsWith(".")) {
      return;
    }

    if (expression.endsWith("%")) {
      return;
    }

    expression += "%";
    justEvaluated = false;
    updateDisplay();
    return;
  }

  if (operators.includes(value)) {
    if (!expression) {
      if (value === "-") {
        expression = "-";
        updateDisplay();
      }
      return;
    }

    if (expression.endsWith(".")) {
      return;
    }

    if (endsWithOperator(expression)) {
      expression = expression.slice(0, -1) + value;
    } else {
      expression += value;
    }

    justEvaluated = false;
    updateDisplay();
  }
}

function clearAll() {
  expression = "";
  justEvaluated = false;
  updateDisplay();
}

function deleteLast() {
  if (!expression) {
    return;
  }

  expression = expression.slice(0, -1);
  justEvaluated = false;
  updateDisplay();
}

function calculate() {
  if (!expression || endsWithOperator(expression) || expression.endsWith(".")) {
    return;
  }

  try {
    const value = evaluateExpression(expression);
    const formatted = formatResult(value);

    addToHistory(expression, formatted);
    expression = formatted;
    justEvaluated = true;
    updateDisplay();
  } catch {
    resultEl.textContent = "Error";
  }
}

function handleAction(action) {
  if (action === "clear") {
    clearAll();
    return;
  }

  if (action === "delete") {
    deleteLast();
    return;
  }

  if (action === "equals") {
    calculate();
  }
}

function evaluateExpression(input) {
  const tokens = tokenize(input);
  const postfix = toPostfix(tokens);
  return evalPostfix(postfix);
}

function tokenize(input) {
  const tokens = [];
  let i = 0;

  while (i < input.length) {
    const char = input[i];

    if (operators.includes(char)) {
      if (char === "-" && (i === 0 || operators.includes(input[i - 1]))) {
        let num = "-";
        i += 1;

        while (i < input.length && (isDigit(input[i]) || input[i] === ".")) {
          num += input[i];
          i += 1;
        }

        if (input[i] === "%") {
          num = String(Number(num) / 100);
          i += 1;
        }

        if (num === "-" || num === "-.") {
          throw new Error("Invalid negative number");
        }

        tokens.push(Number(num));
        continue;
      }

      tokens.push(char);
      i += 1;
      continue;
    }

    if (isDigit(char) || char === ".") {
      let num = "";

      while (i < input.length && (isDigit(input[i]) || input[i] === ".")) {
        num += input[i];
        i += 1;
      }

      if (num === ".") {
        throw new Error("Invalid decimal");
      }

      let value = Number(num);
      if (Number.isNaN(value)) {
        throw new Error("Invalid number");
      }

      if (input[i] === "%") {
        value = value / 100;
        i += 1;
      }

      tokens.push(value);
      continue;
    }

    throw new Error("Unsupported character");
  }

  return tokens;
}

function toPostfix(tokens) {
  const output = [];
  const stack = [];
  const precedence = {
    "+": 1,
    "-": 1,
    "*": 2,
    "/": 2
  };

  for (const token of tokens) {
    if (typeof token === "number") {
      output.push(token);
      continue;
    }

    while (
      stack.length &&
      precedence[stack[stack.length - 1]] >= precedence[token]
    ) {
      output.push(stack.pop());
    }

    stack.push(token);
  }

  while (stack.length) {
    output.push(stack.pop());
  }

  return output;
}

function evalPostfix(postfix) {
  const stack = [];

  for (const token of postfix) {
    if (typeof token === "number") {
      stack.push(token);
      continue;
    }

    const b = stack.pop();
    const a = stack.pop();

    if (a === undefined || b === undefined) {
      throw new Error("Invalid expression");
    }

    let value;
    if (token === "+") value = a + b;
    else if (token === "-") value = a - b;
    else if (token === "*") value = a * b;
    else {
      if (b === 0) {
        throw new Error("Cannot divide by zero");
      }
      value = a / b;
    }

    stack.push(value);
  }

  if (stack.length !== 1 || !Number.isFinite(stack[0])) {
    throw new Error("Invalid result");
  }

  return stack[0];
}

function addToHistory(exp, res) {
  history.unshift(`${exp} = ${res}`);
  if (history.length > 8) {
    history.pop();
  }

  renderHistory();
}

function renderHistory() {
  historyList.innerHTML = "";

  if (history.length === 0) {
    const li = document.createElement("li");
    li.textContent = "No calculations yet";
    historyList.appendChild(li);
    return;
  }

  for (const item of history) {
    const li = document.createElement("li");
    li.textContent = item;
    li.setAttribute("title", item);
    historyList.appendChild(li);
  }
}

function canAddDecimal(exp) {
  if (!exp || endsWithOperator(exp) || exp.endsWith("%")) {
    return true;
  }

  const current = getCurrentNumber(exp);
  return !current.includes(".");
}

function needsLeadingZeroForDecimal(exp) {
  return !exp || endsWithOperator(exp) || exp.endsWith("%") || exp === "-";
}

function getCurrentNumber(exp) {
  let i = exp.length - 1;
  while (i >= 0 && !operators.includes(exp[i])) {
    i -= 1;
  }
  return exp.slice(i + 1);
}

function endsWithOperator(exp) {
  return operators.some((op) => exp.endsWith(op));
}

function formatResult(num) {
  // Restrict precision to avoid floating point noise while preserving decimals.
  const rounded = Number(num.toFixed(12));
  return String(rounded);
}

function isDigit(char) {
  return char >= "0" && char <= "9";
}

function animatePress(valueOrAction) {
  const key = Array.from(keys).find((btn) => {
    return btn.dataset.value === valueOrAction || btn.dataset.action === valueOrAction;
  });

  if (!key) {
    return;
  }

  key.classList.add("pressed");
  window.setTimeout(() => key.classList.remove("pressed"), 120);
}

keys.forEach((key) => {
  key.addEventListener("click", () => {
    const value = key.dataset.value;
    const action = key.dataset.action;

    if (value) {
      appendValue(value);
      animatePress(value);
      return;
    }

    if (action) {
      handleAction(action);
      animatePress(action);
    }
  });
});

document.addEventListener("keydown", (event) => {
  const { key } = event;

  if (isDigit(key) || operators.includes(key) || key === "." || key === "%") {
    appendValue(key);
    animatePress(key);
    return;
  }

  if (key === "Enter" || key === "=") {
    event.preventDefault();
    calculate();
    animatePress("equals");
    return;
  }

  if (key === "Backspace") {
    deleteLast();
    animatePress("delete");
    return;
  }

  if (key === "Escape" || key.toLowerCase() === "c") {
    clearAll();
    animatePress("clear");
  }
});

historyToggle.addEventListener("click", () => {
  const isHidden = historyPanel.hasAttribute("hidden");

  if (isHidden) {
    historyPanel.removeAttribute("hidden");
  } else {
    historyPanel.setAttribute("hidden", "");
  }
});

renderHistory();
updateDisplay();
