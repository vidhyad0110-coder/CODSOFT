const Project = require('../models/Project');
const Task = require('../models/Task');

// @desc  Search projects and tasks
// @route GET /api/search?q=query
exports.search = async (req, res) => {
  const { q } = req.query;
  if (!q) return res.json({ success: true, projects: [], tasks: [] });
  const regex = new RegExp(q, 'i');
  const userProjects = await Project.find({ $or: [{ owner: req.user.id }, { members: req.user.id }] }).select('_id');
  const projectIds = userProjects.map(p => p._id);
  const [projects, tasks] = await Promise.all([
    Project.find({ _id: { $in: projectIds }, $or: [{ title: regex }, { description: regex }] }).select('title description status priority').limit(10),
    Task.find({ project: { $in: projectIds }, $or: [{ title: regex }, { description: regex }] }).select('title status priority project').populate('assignee', 'name avatar').limit(10),
  ]);
  res.json({ success: true, projects, tasks });
};
