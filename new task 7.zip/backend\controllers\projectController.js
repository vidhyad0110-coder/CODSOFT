const Project = require('../models/Project');
const Task = require('../models/Task');
const Notification = require('../models/Notification');

// @desc  Get all projects (user is member or owner)
// @route GET /api/projects
exports.getProjects = async (req, res) => {
  const projects = await Project.find({
    $or: [{ owner: req.user.id }, { members: req.user.id }],
  }).populate('owner', 'name avatar email').populate('members', 'name avatar email').sort('-createdAt');
  res.json({ success: true, count: projects.length, projects });
};

// @desc  Get single project
// @route GET /api/projects/:id
exports.getProject = async (req, res) => {
  const project = await Project.findById(req.params.id)
    .populate('owner', 'name avatar email')
    .populate('members', 'name avatar email');
  if (!project) return res.status(404).json({ success: false, message: 'Project not found' });
  res.json({ success: true, project });
};

// @desc  Create project
// @route POST /api/projects
exports.createProject = async (req, res) => {
  const { title, description, status, priority, deadline, members, color, tags } = req.body;
  const project = await Project.create({ title, description, status, priority, deadline, members, color, tags, owner: req.user.id });
  await project.populate('owner', 'name avatar email');
  await project.populate('members', 'name avatar email');
  res.status(201).json({ success: true, project });
};

// @desc  Update project
// @route PUT /api/projects/:id
exports.updateProject = async (req, res) => {
  let project = await Project.findById(req.params.id);
  if (!project) return res.status(404).json({ success: false, message: 'Project not found' });
  if (project.owner.toString() !== req.user.id && req.user.role !== 'admin') {
    return res.status(403).json({ success: false, message: 'Not authorized to update this project' });
  }
  project = await Project.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true })
    .populate('owner', 'name avatar email').populate('members', 'name avatar email');
  res.json({ success: true, project });
};

// @desc  Delete project
// @route DELETE /api/projects/:id
exports.deleteProject = async (req, res) => {
  const project = await Project.findById(req.params.id);
  if (!project) return res.status(404).json({ success: false, message: 'Project not found' });
  if (project.owner.toString() !== req.user.id && req.user.role !== 'admin') {
    return res.status(403).json({ success: false, message: 'Not authorized to delete this project' });
  }
  await Task.deleteMany({ project: req.params.id });
  await project.deleteOne();
  res.json({ success: true, message: 'Project deleted' });
};

// @desc  Add member to project
// @route POST /api/projects/:id/members
exports.addMember = async (req, res) => {
  const project = await Project.findById(req.params.id);
  if (!project) return res.status(404).json({ success: false, message: 'Project not found' });
  const { userId } = req.body;
  if (!project.members.includes(userId)) {
    project.members.push(userId);
    await project.save();
    await Notification.create({ user: userId, message: `You have been added to project: ${project.title}`, type: 'project_invite', link: `/projects/${project._id}` });
  }
  await project.populate('members', 'name avatar email');
  res.json({ success: true, project });
};

// @desc  Remove member from project
// @route DELETE /api/projects/:id/members/:userId
exports.removeMember = async (req, res) => {
  const project = await Project.findById(req.params.id);
  if (!project) return res.status(404).json({ success: false, message: 'Project not found' });
  project.members = project.members.filter(m => m.toString() !== req.params.userId);
  await project.save();
  res.json({ success: true, project });
};

// @desc  Get project stats
// @route GET /api/projects/:id/stats
exports.getProjectStats = async (req, res) => {
  const tasks = await Task.find({ project: req.params.id });
  const total = tasks.length;
  const completed = tasks.filter(t => t.status === 'completed').length;
  const inProgress = tasks.filter(t => t.status === 'in_progress').length;
  const todo = tasks.filter(t => t.status === 'todo').length;
  const review = tasks.filter(t => t.status === 'review').length;
  const progress = total > 0 ? Math.round((completed / total) * 100) : 0;
  res.json({ success: true, stats: { total, completed, inProgress, todo, review, progress } });
};
