const Attachment = require('../models/Attachment');
const path = require('path');

// @desc  Upload file for a task
// @route POST /api/upload/:taskId
exports.uploadFile = async (req, res) => {
  if (!req.file) return res.status(400).json({ success: false, message: 'No file uploaded' });
  const fileUrl = `/uploads/${req.file.filename}`;
  const attachment = await Attachment.create({
    task: req.params.taskId,
    filename: req.file.filename,
    originalName: req.file.originalname,
    mimetype: req.file.mimetype,
    size: req.file.size,
    url: fileUrl,
    uploadedBy: req.user.id,
  });
  await attachment.populate('uploadedBy', 'name');
  res.status(201).json({ success: true, attachment });
};

// @desc  Get attachments for a task
// @route GET /api/upload/:taskId
exports.getAttachments = async (req, res) => {
  const attachments = await Attachment.find({ task: req.params.taskId }).populate('uploadedBy', 'name avatar');
  res.json({ success: true, attachments });
};

// @desc  Delete attachment
// @route DELETE /api/upload/:id
exports.deleteAttachment = async (req, res) => {
  const attachment = await Attachment.findById(req.params.id);
  if (!attachment) return res.status(404).json({ success: false, message: 'Attachment not found' });
  const fs = require('fs');
  const filePath = path.join(__dirname, '../uploads', attachment.filename);
  if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
  await attachment.deleteOne();
  res.json({ success: true });
};
