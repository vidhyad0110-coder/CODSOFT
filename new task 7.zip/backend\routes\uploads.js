const express = require('express');
const router = express.Router();
const upload = require('../middleware/upload');
const { protect } = require('../middleware/auth');
const { uploadFile, getAttachments, deleteAttachment } = require('../controllers/uploadController');

router.route('/:taskId').get(protect, getAttachments).post(protect, upload.single('file'), uploadFile);
router.delete('/:id', protect, deleteAttachment);

module.exports = router;
