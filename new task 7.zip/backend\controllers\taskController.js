const Task = require('../models/Task');
const Project = require('../models/Project');
const Comment = require('../models/Comment');
const Notification = require('../models/Notification');

// @desc  Get tasks for a project
// @route GET /api/tasks?project=:projectId
exports.getTasks = async (req, res) => {
  const filter = {};
  if (req.query.project) filter.project = req.query.project;
  if (req.query.status) filter.status = req.query.status;
  if (req.query.priority) filter.priority = req.query.priority;
  if (req.query.assignee) filter.assignee = req.query.assignee;
  const tasks = await Task.find(filter)
    .populate('assignee', 'name avatar email')
    .populate('createdBy', 'name avatar email')
    .sort('order');
  res.json({ success: true, count: tasks.length, tasks });
};

// @desc  Get single task
// @route GET /api/tasks/:id
exports.getTask = async (req, res) => {
  const task = await Task.findById(req.params.id)
    .populate('assignee', 'name avatar email')
    .populate('createdBy', 'name avatar email')
    .populate({ path: 'comments', populate: { path: 'author', select: 'name avatar' } })
    .populate({ path: 'attachments', populate: { path: 'uploadedBy', select: 'name' } });
  if (!task) return res.status(404).json({ success: false, message: 'Task not found' });
  res.json({ success: true, task });
};

// @desc  Create task
// @route POST /api/tasks
exports.createTask = async (req, res) => {
  const { title, description, project, assignee, status, priority, deadline, tags } = req.body;
  const task = await Task.create({ title, description, project, assignee, status, priority, deadline, tags, createdBy: req.user.id });
  await task.populate('assignee', 'name avatar email');
  await task.populate('createdBy', 'name avatar email');
  // Notify assignee
  if (assignee && assignee.toString() !== req.user.id) {
    const proj = await Project.findById(project);
    await Notification.create({ user: assignee, message: `You have been assigned a task: "${title}" in ${proj?.title || 'a project'}`, type: 'task_assigned', link: `/tasks/${task._id}` });
  }
  res.status(201).json({ success: true, task });
};

// @desc  Update task
// @route PUT /api/tasks/:id
exports.updateTask = async (req, res) => {
  let task = await Task.findById(req.params.id);
  if (!task) return res.status(404).json({ success: false, message: 'Task not found' });
  const prevAssignee = task.assignee?.toString();
  task = await Task.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true })
    .populate('assignee', 'name avatar email')
    .populate('createdBy', 'name avatar email');
  // Notify new assignee if changed
  if (req.body.assignee && req.body.assignee !== prevAssignee && req.body.assignee !== req.user.id) {
    await Notification.create({ user: req.body.assignee, message: `You have been assigned task: "${task.title}"`, type: 'task_assigned', link: `/tasks/${task._id}` });
  }
  res.json({ success: true, task });
};

// @desc  Delete task
// @route DELETE /api/tasks/:id
exports.deleteTask = async (req, res) => {
  const task = await Task.findById(req.params.id);
  if (!task) return res.status(404).json({ success: false, message: 'Task not found' });
  await Comment.deleteMany({ task: task._id });
  await task.deleteOne();
  res.json({ success: true, message: 'Task deleted' });
};

// @desc  Add comment to task
// @route POST /api/tasks/:id/comments
exports.addComment = async (req, res) => {
  const task = await Task.findById(req.params.id);
  if (!task) return res.status(404).json({ success: false, message: 'Task not found' });
  const comment = await Comment.create({ task: task._id, author: req.user.id, content: req.body.content });
  await comment.populate('author', 'name avatar');
  res.status(201).json({ success: true, comment });
};

// @desc  Get comments for a task
// @route GET /api/tasks/:id/comments
exports.getComments = async (req, res) => {
  const comments = await Comment.find({ task: req.params.id })
    .populate('author', 'name avatar email')
    .sort('createdAt');
  res.json({ success: true, comments });
};

// @desc  Update task order (drag-drop)
// @route PUT /api/tasks/reorder
exports.reorderTasks = async (req, res) => {
  const { tasks } = req.body; // [{ id, status, order }]
  const bulkOps = tasks.map(t => ({
    updateOne: { filter: { _id: t.id }, update: { status: t.status, order: t.order } },
  }));
  await Task.bulkWrite(bulkOps);
  res.json({ success: true });
};

// @desc  Dashboard stats
// @route GET /api/tasks/stats
exports.getStats = async (req, res) => {
  const userProjects = await Project.find({ $or: [{ owner: req.user.id }, { members: req.user.id }] }).select('_id');
  const projectIds = userProjects.map(p => p._id);
  const total = await Task.countDocuments({ project: { $in: projectIds } });
  const completed = await Task.countDocuments({ project: { $in: projectIds }, status: 'completed' });
  const inProgress = await Task.countDocuments({ project: { $in: projectIds }, status: 'in_progress' });
  const todo = await Task.countDocuments({ project: { $in: projectIds }, status: 'todo' });
  const overdue = await Task.countDocuments({ project: { $in: projectIds }, deadline: { $lt: new Date() }, status: { $ne: 'completed' } });
  res.json({ success: true, stats: { total, completed, inProgress, todo, overdue, projects: projectIds.length } });
};
