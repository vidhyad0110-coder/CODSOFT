const express = require('express');
const router = express.Router();
const { getTasks, getTask, createTask, updateTask, deleteTask, addComment, getComments, reorderTasks, getStats } = require('../controllers/taskController');
const { protect } = require('../middleware/auth');

router.get('/stats', protect, getStats);
router.put('/reorder', protect, reorderTasks);
router.route('/').get(protect, getTasks).post(protect, createTask);
router.route('/:id').get(protect, getTask).put(protect, updateTask).delete(protect, deleteTask);
router.route('/:id/comments').get(protect, getComments).post(protect, addComment);

module.exports = router;
