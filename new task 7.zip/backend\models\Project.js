const mongoose = require('mongoose');

const projectSchema = new mongoose.Schema({
  title: { type: String, required: [true, 'Title is required'], trim: true },
  description: { type: String, default: '' },
  status: { type: String, enum: ['not_started', 'in_progress', 'completed', 'delayed'], default: 'not_started' },
  priority: { type: String, enum: ['low', 'medium', 'high', 'critical'], default: 'medium' },
  deadline: { type: Date },
  owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  members: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  color: { type: String, default: '#6366f1' },
  tags: [String],
  progress: { type: Number, default: 0, min: 0, max: 100 },
}, { timestamps: true });

module.exports = mongoose.model('Project', projectSchema);
