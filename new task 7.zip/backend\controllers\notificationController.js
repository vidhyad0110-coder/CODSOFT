const Notification = require('../models/Notification');

// @desc  Get user notifications
// @route GET /api/notifications
exports.getNotifications = async (req, res) => {
  const notifications = await Notification.find({ user: req.user.id }).sort('-createdAt').limit(50);
  const unreadCount = await Notification.countDocuments({ user: req.user.id, isRead: false });
  res.json({ success: true, notifications, unreadCount });
};

// @desc  Mark notification as read
// @route PUT /api/notifications/:id/read
exports.markRead = async (req, res) => {
  await Notification.findByIdAndUpdate(req.params.id, { isRead: true });
  res.json({ success: true });
};

// @desc  Mark all as read
// @route PUT /api/notifications/read-all
exports.markAllRead = async (req, res) => {
  await Notification.updateMany({ user: req.user.id, isRead: false }, { isRead: true });
  res.json({ success: true });
};

// @desc  Delete notification
// @route DELETE /api/notifications/:id
exports.deleteNotification = async (req, res) => {
  await Notification.findByIdAndDelete(req.params.id);
  res.json({ success: true });
};
